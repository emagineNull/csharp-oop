﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animals
{
    public class Snake : Reptile
    {
        public Snake(string name)
            : base(name)
        {

        }
    }
}
